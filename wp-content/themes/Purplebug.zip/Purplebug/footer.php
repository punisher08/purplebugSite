<footer class="site-footer mt-5">
<!-- <svg  class="footer-svg" height="500" viewBox="0 0 1040 500" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.822409 412.598C335.443 356.181 942.281 446.196 1054 31.7383V500H0.822409V412.598Z" fill="#144F4B"/>
<path d="M0 409.118C327.315 352.642 944.719 414.889 1054 0V468.75H0V409.118Z" fill="#144F4B" fill-opacity="0.84"/>
</svg> -->
</footer>
<div class="top-header row">
          <div class="container d-flex">
           <div class="col-md-8 d-flex align-items-center text-white">
                <p class="mx-3">@2018 QQBLOGS THEME BY WEBDEVZAP. ALL RIGHT RESERVED.</p>
           </div>
           <div class="col-lg-4 d-flex align-items-center text-white">
                <div class="add-to-menu">ADD A MENU</div>
           </div>
        </div>
        </div>
</div> <!-- closes <div class=container"> -->

<?php wp_footer() ?>
</body>
</html> 
