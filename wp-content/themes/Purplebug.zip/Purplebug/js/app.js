setTimeout(() => {
    document.getElementById("s").placeholder = "Enter text..."; 
}, 200);

